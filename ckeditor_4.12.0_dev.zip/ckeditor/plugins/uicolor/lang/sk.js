﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","sk",{title:"UI výber farby",options:"Možnosti farby",highlight:"Zvýrazniť",selected:"Vybraná farba",predefined:"Preddefinované sady farieb",config:"Vložte tento reťazec do svojho súboru config.js"});